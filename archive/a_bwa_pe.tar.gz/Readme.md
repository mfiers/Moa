**On Tuesday, 14 Feb 2012 15:38 - cflmwf writes**

Make sure that you cp/ln a reference sequence to ./00.reference/reference.fasta and
    copy/ln a set of libraries in a directory as follows: ./05.fq/LIBNAME
    all fq files should end in _1.fq and _2.fq for the read pairs
-----
